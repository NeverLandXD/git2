const stayonscreen = (pushname, prefix, botName, ownerName) => {
        return `
╔══✪〘 Informações 〙✪══
║
║───────⊹⊱✫⊰⊹───────
║➩ ❍ wa.me/556993899391
║➩ ❍ Prefix: 「  ${prefix}  」
║➩ ❍ Criador: ${botName}
║➩ ❍ Nome: ${pushname}️
║➩ ❍ XP: ${reqXp}
║➩ ❍ Money: ${uangku}
───────⊹⊱✫⊰⊹───────


                    𝚉𝙴𝚄𝚂

───────⊹⊱✫⊰⊹───────
║➩ ❍  *${prefix}info*
║➩ ❍  *${prefix}blocklist*
║➩ ❍  *${prefix}chatlist*
║➩ ❍  *${prefix}ping*
║➩ ❍  *${prefix}bugreport*
║➩ ❍  *${prefix}afk*
║➩ Aumente seu level interagindo no grupo!!
║───────⊹⊱✫⊰⊹───────`
}
exports.stayonscreen = stayonscreen
